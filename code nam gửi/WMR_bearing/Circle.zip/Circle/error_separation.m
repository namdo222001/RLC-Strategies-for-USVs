% clc; 

% Load data
%load("psi_values.mat")      % psi_values
%load("psi_values_nam.mat")
load("L_values_circle_v2.mat")
% Number of samples
% N = numel(psi_values);
N = numel(L_values_circle);

% Time
dt = 70/709;
t  = 70;

% Desired signal
%psid = (4*pi/3) * ones(N,1);
Lsid = (10) * ones(N,1);
% Error (1D signal)
%e = abs(psi_nam_v2 - psid)';
e_l = abs(L_values_circle - Lsid)';
% Performance indices
IAE2  = trapz(t, e_l);
ITAE2 = trapz(t, t .* e_l);
% RMSE1 = sqrt(mean((psi_values - psid).^2));
RMSE2 = sqrt(mean((L_values_circle - Lsid).^2));

% Display
IAE2
ITAE2
RMSE2
